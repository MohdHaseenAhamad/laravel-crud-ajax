<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Users;
use function Psr\Log\debug;

class UsersController extends Controller
{
    public function save(Request $request)
    {
        $obj = new Users();
        $obj->usr_fname = $request['fname'];
        $obj->usr_lname = $request['lname'];
        if($request->file('image')){
            $file= $request->file('image');
            $filename= date('YmdHi').$file->getClientOriginalName();
            $file-> move(public_path('upload/Image'), $filename);
            $obj->usr_image= $filename;
        }
        $obj->usr_email = $request['email'];
        $obj->usr_phone = $request['phone'];
        $obj->usr_gender = $request['gender'];
        $obj->usr_dob = $request['dob'];
        $obj->cnt_id = $request['country'];
        $obj->sts_id = $request['state'];
        $obj->dis_id = $request['city'];
        $obj->usr_address = $request['address'];
        $obj->usr_pincode = $request['pincode'];
        $obj->user_ip_address = get_ip_address();
        if ($obj->save())
        {
            echo "true";
        }
        else
        {
            echo "false";
        }
    }
    public function edit(Request $request)
    {
//        print_r($request);die;

        $data = [
            'usr_fname'=> $request['edit_fname'],
            'usr_lname'=> $request['edit_lname'],
            'usr_email'=> $request['edit_email'],
            'usr_phone'=> $request['edit_phone'],
            'usr_gender'=> $request['edit_gender'],
            'usr_dob'=> $request['edit_dob'],
            'cnt_id'=> $request['edit_country'],
            'sts_id'=> $request['edit_state'],
            'dis_id'=> $request['edit_city'],
            'usr_address'=> $request['edit_address'],
            'usr_pincode'=> $request['edit_pincode'],
        ];
//        print_r($request->file('image'));die;
        if($request->file('edit_image')){
            $file= $request->file('edit_image');
            $filename= date('YmdHi').$file->getClientOriginalName();
            $file-> move(public_path('upload/Image'), $filename);
            $data['usr_image']= $filename;
        }
        else
        {
            $data['usr_image']= $request['edit_image_old'];
        }
//        print_r($request->file('image'));die;
//        $users = \DB::table('flights_crd_users')
//            ->where('id', $request['data_id'])
//            ->update($data);
        $users =Users::where('usr_id',$request['data_id'])->update($data);
        if($users)
        {
            echo "true";
        }
        else
        {
            echo "false";
        }


    }
    public function delete()
    {
        $id = $_POST['id'] ?? null;
        $users =Users::where('id',$id)->delete();
        if($users)
        {
            echo "true";
        }
        else
        {
            echo "false";
        }


    }
    public function getUsers()
    {
        $id = $_POST['id'] ?? null;
        if(!empty($id))
        {
            $users = \DB::table('flights_crd_users')->where('usr_id',$id)->get();
//            $users = \DB::table('flights_crd_users')->find($id);
            if (count($users) > 0) {
                return response()->json($users[0]);
            }
        }
        else{
//            $users = \DB::table('flights_crd_users')->orderBy('id', 'DESC')
//                ->get();
            $users = \DB::select('select usr_id,usr_image,usr_fname,usr_lname,usr_dob,usr_email,usr_gender,usr_pincode,usr_address,usr_phone,cnt_name as country_name, sts_name as state_name, dis_name as city_name  from flights_crd_users as u join countries as c on c.cnt_id  = u.cnt_id join states as s on s.sts_id = u.sts_id join cities as city on city.dis_id = u.dis_id');
//            $users = \DB::table('flights_crd_users as user')
//                ->join('countries as cnt', 'user.cnt_id', '=', 'cnt.cnt_id')
//                ->join('states as sts', 'user.sts_id', '=', 'sts.sts_id')
//                ->join('cities as dis', 'user.dis_id', '=', 'dis.dis_id')
//                ->select('usr_id,usr_image,usr_fname,usr_lname,usr_dob,usr_email,usr_gender,usr_pincode,usr_address,usr_phone,cnt_name as country_name, sts_name as state_name, dis_name as city_name')
//                ->paginate(10);
//            $users = Users::paginate(5);
            if (count($users) > 0) {
                return response()->json($users);
            }
        }

    }
    public function getTestUsers()
    {
        $users= Users::paginate(10);

//                    $users = \DB::table('flights_crd_users')->select('usr_id,usr_image,usr_fname,usr_lname,usr_dob,usr_email,usr_gender,usr_pincode,usr_address,usr_phone');
print_r($users);die;

    }
}
