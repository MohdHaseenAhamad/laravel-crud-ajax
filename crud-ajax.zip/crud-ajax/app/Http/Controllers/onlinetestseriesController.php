<?php
/**
 * Created by PhpStorm.
 * User: MG-CLIENT-14
 * Date: 7/27/2022
 * Time: 3:53 PM
 */

namespace App\Http\Controllers;


class OnlineTestSeriesController extends Controller{

    public function index()
    {
        return view('OnlineTestSeries/index');
    }
}