<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Users extends Model
{
    use HasFactory;
    protected $table = 'flights_crd_users';
    protected $fillable = [
        'usr_fname',
        'usr_lname',
        'usr_image',
        'usr_email',
        'usr_phone',
        'usr_gender',
        'usr_dob',
        'cnt_id',
        'sts_id',
        'dis_id',
        'usr_address',
        'usr_pincode',
        'user_ip_address',
        // add all other fields
    ];
}
