<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('flights_crd_users',function (Blueprint $table){
            $table->id();
            $table->string('fname',50);
            $table->string('lname',50);
            $table->string('email',50)->unique();
            $table->string('phone',50);
            $table->enum('gender',['male','female','other']);
            $table->string('dob',30);
            $table->integer('cnt_id');
            $table->integer('sts_id');
            $table->integer('dis_id');
            $table->string('address',100)->after('dis_id');
            $table->string('pincode',20)->after('address');
            $table->string('user_ip_address',50);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('crd_users');
    }
};
