<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <title>CRUD AJAX!</title>
    <style>
        .container {
            max-width: 100%;
            margin-top: 0px;
            /*border: 2px solid;*/
        }
        .input-group {
            width: 100%;
            padding-right: 8px;
            margin-top: 20px;
        }

        .has-error {
            border: 1px dotted red;
        }


    </style>
</head>
<body>