@include('common.header')
<link rel="stylesheet" href="{{asset('assets/css/component-chosen.css') }}"/>
<link href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/8.4.6/css/intlTelInput.css" rel="stylesheet"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.css" integrity="sha512-nNlU0WK2QfKsuEmdcTwkeh+lhGs6uyOxuUs+n+0oXSYDok5qy0EI0lt01ZynHq6+p/tbgpZ7P+yUb+r71wqdXg==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<div class="container">
    <div class="row">

        <div class="col-md-12" style="margin-bottom: 20px;padding-top: 20px">
            <button class="btn btn-primary" data-toggle="modal" data-target=".bd-example-modal-lg"><i class="fa fa-plus"
                                                                                                      aria-hidden="true"></i>&nbsp;
            </button>
            <button class="btn btn-primary " id="edit_data" data-toggle="modal" data-target=".ed-bd-example-modal-lg"
                    style="display: none"><i class="fa fa-plus"
                                             aria-hidden="true"></i>&nbsp;Add
                Records
            </button>
        </div>
    </div>
    <div class="row" style="margin-bottom: 20px;padding-top: 20px">

            <div class="col-3">
                <div class="input-group ">

                    <input type="text" class="form-control" name="filter_name" id="filter_name"
                           placeholder="First Name"
                           aria-label="First Name"
                           aria-describedby="basic-addon1">
                </div>
            </div>
            <div class="col-3">
                <div class="input-group">
                    <input type="text" class="form-control" name="filter_email" id="filter_email"
                           placeholder="Email"
                           aria-label="email"
                           aria-describedby="basic-addon1">
                </div>
            </div>
        <div class="col-3">
            <div class="input-group">
                <button type="button" class="btn btn-success" id="filter_button">submit</button>
            </div>
        </div>

    </div>
    <div class="row">
        {{--<div class="clearfix"></div>--}}
        <div class="col-md-12">
            <table class="table">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Image</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Phone</th>
                    <th scope="col">Date of Birth</th>
                    <th scope="col">Gender</th>
                    <th scope="col">Address</th>
                    <th scope="col">Location</th>
                    <th scope="col">Pincode</th>
                    <th scope="col">Action</th>
                </tr>
                </thead>
                <tbody class="users">

                </tbody>
            </table>
        </div>
        {{--ADD RECORD MODEL--}}
        <div class="modal fade bd-example-modal-lg" tabindex="-1" id="add-model" role="dialog"
             aria-labelledby="myLargeModalLabel"
             aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">ADD RECORD</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form method="POST" name="save_user_data" id="save_user_data" class="btn-submit"
                          action="{{ route('save')  }}" enctype="multipart/form-data">
                        @csrf
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-12">
                                    <div class="image">

                                        <div class="col-12" style="text-align: center">
                                            <label><h4 >View image</h4></label><br>
                                            <img src="{{asset('upload/Image')}}/no-image.jpg" alt="..."  class="img-thumbnail" style="width: 100px;height: 100px">
                                        </div>
                                        {{--<div class="col-12">--}}
                                        <label><h4>Change image</h4></label>
                                        <input type="file" class="form-control"  name="image" id="image" >

                                        {{--</div>--}}
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="input-group ">

                                        <input type="text" class="form-control" name="fname" id="fname"
                                               placeholder="First Name"
                                               aria-label="First Name"
                                               aria-describedby="basic-addon1">
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="input-group ">

                                        <input type="text" class="form-control" name="lname" id="lname"
                                               placeholder="Last Name"
                                               aria-label="Last Name"
                                               aria-describedby="basic-addon1">
                                    </div>
                                </div>


                                <div class="col-6">
                                    <div class="input-group">

                                        <input type="email" class="form-control" name="email" id="email"
                                               placeholder="Email"
                                               aria-label="Email"
                                               aria-describedby="basic-addon1">
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="input-group ">
                                        <input type="tel" class="form-control" name="phone" id="phone"
                                               placeholder="Phone Number"
                                               aria-label="Phone Number"
                                               aria-describedby="basic-addon1">
                                        <input type="hidden" class="form-control" name="cnt_iso_phone"
                                               id="cnt_iso_phone">
                                        <input type="hidden" class="form-control" name="cnt_isd_phone"
                                               id="cnt_iso_phone">
                                    </div>
                                </div>


                                <div class="col-6">
                                    <div class="input-group">
                                        <select id="gender" name="gender" class="form-control form-control-chosen"
                                                data-placeholder="Please select gender">
                                            <option value="">Select Gender</option>
                                            <option value="male">Male</option>
                                            <option value="female">Female</option>
                                            <option value="other">Other</option>
                                        </select>

                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="input-group">
                                        <input type="date" class="form-control" name="dob" id="dob"
                                               placeholder="Date Of Birth"
                                               aria-label="Date Of Birth"
                                               aria-describedby="basic-addon1">

                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="input-group">
                                        <select id="country" name="country" class="form-control form-control-chosen"
                                                data-placeholder="Please select Country">
                                            <option value="">Select Country</option>
                                            @foreach ($countries as $country)
                                                <option value="{{ $country->cnt_id }}">{{ $country->cnt_name }}</option>
                                            @endforeach
                                        </select>

                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="input-group">
                                        <select id="state" name="state" class="form-control "
                                                data-placeholder="Please select State">
                                        </select>

                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="input-group">
                                        <select id="city" name="city" class="form-control "
                                                data-placeholder="Please select City">
                                        </select>

                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="input-group">
                                        <input type="text" class="form-control" name="address" id="address"
                                               placeholder="Your Address"
                                               aria-label="Your Address"
                                               aria-describedby="basic-addon1">
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="input-group">

                                        <input type="text" class="form-control" name="pincode" id="pincode"
                                               placeholder="Your Postal Code"
                                               aria-label="Your Postal Code"
                                               aria-describedby="basic-addon1">
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="modal-footer">

                            <button type="button" class="btn btn-secondary close_link" data-dismiss="modal">Close
                            </button>
                            <button class="btn btn-primary">Save changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        {{--End ADD RECORD MODEL--}}
        {{--Edit RECORD MODEL--}}
        <div class="modal fade ed-bd-example-modal-lg" tabindex="-1" id="edit-model" role="dialog"
             aria-labelledby="myLargeModalLabel"
             aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">EDIT RECORD</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form method="POST" name="edit_user_data" id="edit_user_data" class="btn-submit"
                          action="{{ route('edit')  }}" enctype="multipart/form-data">
                        @csrf

                        <div class="modal-body">
                            <div class="row">
                                <div class="col-12">
                                <div class="image">

                                    <div class="col-12" style="text-align: center">
                                        <label><h4 >View image</h4></label><br>
                                    <img src="" alt="..." id="edit_image_view" class="img-thumbnail" style="width: 100px;height: 100px">
                                    </div>
                                    {{--<div class="col-12">--}}
                                        <label><h4>Change image</h4></label>
                                    <input type="file" class="form-control"  name="edit_image" id="edit_image" >
                                    <input type="hidden" class="form-control"  name="edit_image_old" id="edit_image_old" >
                                    {{--</div>--}}
                                </div>
                                </div>
                                <div class="col-6">
                                    <div class="input-group ">

                                        <input type="text" class="form-control" name="edit_fname" id="edit_fname"
                                               placeholder="First Name"
                                               aria-label="First Name"
                                               aria-describedby="basic-addon1">
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="input-group ">

                                        <input type="text" class="form-control" name="edit_lname" id="edit_lname"
                                               placeholder="Last Name"
                                               aria-label="Last Name"
                                               aria-describedby="basic-addon1">
                                    </div>
                                </div>


                                <div class="col-6">
                                    <div class="input-group">

                                        <input type="email" class="form-control" name="edit_email" id="edit_email"
                                               placeholder="Email"
                                               aria-label="Email"
                                               aria-describedby="basic-addon1">
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="input-group ">
                                        <input type="tel" class="form-control" name="edit_phone" id="edit_phone"
                                               placeholder="Phone Number"
                                               aria-label="Phone Number"
                                               aria-describedby="basic-addon1">
                                        <input type="hidden" class="form-control" name="cnt_iso_phone"
                                               id="cnt_iso_phone">
                                        <input type="hidden" class="form-control" name="cnt_isd_phone"
                                               id="cnt_iso_phone">
                                    </div>
                                </div>


                                <div class="col-6">
                                    <div class="input-group">
                                        <select id="edit_gender" name="edit_gender" class="form-control form-control-chosen"
                                                data-placeholder="Please select gender">
                                            <option value="">Select Gender</option>
                                            <option value="male">Male</option>
                                            <option value="female">Female</option>
                                            <option value="other">Other</option>
                                        </select>

                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="input-group">
                                        <input type="date" class="form-control" name="edit_dob" id="edit_dob"
                                               placeholder="Date Of Birth"
                                               aria-label="Date Of Birth"
                                               aria-describedby="basic-addon1">

                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="input-group">
                                        <select id="edit_country" name="edit_country" class="form-control form-control-chosen"
                                                data-placeholder="Please select Country">
                                            <option value="">Select Country</option>
                                            @foreach ($countries as $country)
                                                <option value="{{ $country->cnt_id }}">{{ $country->cnt_name }}</option>
                                            @endforeach
                                        </select>

                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="input-group">
                                        <select id="edit_state" name="edit_state" class="form-control "
                                                data-placeholder="Please select State">
                                        </select>

                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="input-group">
                                        <select id="edit_city" name="edit_city" class="form-control "
                                                data-placeholder="Please select City">
                                        </select>

                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="input-group">
                                        <input type="text" class="form-control" name="edit_address" id="edit_address"
                                               placeholder="Your Address"
                                               aria-label="Your Address"
                                               aria-describedby="basic-addon1">
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="input-group">

                                        <input type="text" class="form-control" name="edit_pincode" id="edit_pincode"
                                               placeholder="Your Postal Code"
                                               aria-label="Your Postal Code"
                                               aria-describedby="basic-addon1">
                                    </div>
                                </div>

                            </div>
                        </div>
                        <input type="hidden" name="data_id" id="data_id" value="">
                        <div class="modal-footer">

                            <button type="button" class="btn btn-secondary close_link" data-dismiss="modal">Close
                            </button>
                            <button class="btn btn-primary" id="update_data">Save changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        {{--End Edit RECORD MODEL--}}

    </div>

</div>

@include('common.footer')
<script src="{{asset('assets/js/jquery.min.js') }}"></script>
<script src="{{asset('assets/js/intlTelInput.js') }}"></script>
<script src="{{asset('assets/js/chosen.jquery.min.js') }}"></script>
{{--<input type="hidden" name="_token" value="{{ csrf_token() }}" />--}}
<script src="{{asset('assets/js/jquery.validate.js') }}"></script>
<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js" integrity="sha512-uURl+ZXMBrF4AwGaWmEetzrd+J5/8NRkWAvJx5sbPSSuOb0bZLqf+tOzniObO00BjHa/dD7gub9oCGMLPQHtQA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script>
    $(document).ready(function () {
        UsersDataGet();

    });

    function UsersDataGet() {
        $.ajax({
            url: '{{ route('getUsers') }}',
            type: 'get',
            success: function (res) {
                let i = 1;
                $.each(res, function (key, value) {
                    $('.users').append('  <tr>\n' +
                        '                    <th scope="row">' + i + '</th>\n' +
                        '                    <th scope="row"><a  href='+'{{asset('upload/Image')}}/' + (value.usr_image==null ? 'no-image.jpg': value.usr_image) + ' class="video_cus_fancy" data-fancybox-type="iframe" data-fancybox-group="group01"><img src="'+'{{asset('upload/Image')}}/' + (value.usr_image==null ? 'no-image.jpg': value.usr_image) + ' " class="img-thumbnail" style="width: 100px;height: 100px"></a></th>\n' +
                        '                    <td>' + value.usr_fname + '</td>\n' +
                        '                    <td>' + value.usr_email + '</td>\n' +
                        '                    <td>' + value.usr_phone + '</td>\n' +
                        '                    <td>' + value.usr_dob + '</td>\n' +
                        '                    <td>' + value.usr_gender + '</td>\n' +
                        '                    <td>' + value.usr_address + '</td>\n' +
                        '                    <td>' + value.country_name + ',' +value.state_name+',' + value.city_name+'</td>\n' +
                        '                    <td>' + value.usr_pincode + '</td>\n' +
                        '                    <td><button class="btn btn-primary data_edit" id="data_edit_' + value.usr_id + '"  data-id="' + value.usr_id + '"><i class="fa fa-edit"></i></button>&nbsp&nbsp<button class="btn btn-danger data_delete" id="data_delete_' + value.usr_id + '"  data-id="' + value.usr_id + '"><i class="fa fa-trash" aria-hidden="true"></i></button></td>\n' +
                        '                </tr>');
                    i = i + 1;
                });

            },
            error: function () {

            },
        });
    }

</script>

<script>
    $("#phone").intlTelInput();
    $("#edit_phone").intlTelInput();
    $('.form-control-chosen').chosen({});
    $(document).ready(function () {
        $('#country').on('change', function () {
            var countryId = this.value;
            $('#state').html('');
            $.ajax({
                url: '{{ route('getStates') }}?country_id=' + countryId,
                type: 'get',
                async:false,
                success: function (res) {

                    $('#state').html('<option value="">Select State</option>');
                    $.each(res, function (key, value) {
                        $('#state').append('<option value="' + value
                            .sts_id + '">' + value.sts_name + '</option>');
                    });
                    $('#city').html('<option value="">Select City</option>');
                }
            });
        });
        $('#state').on('change', function () {
            var stateId = this.value;
            $('#city').html('');
            $.ajax({
                url: '{{ route('getCities') }}?state_id=' + stateId,
                type: 'get',
                async:false,
                success: function (res) {
                    $('#city').html('<option value="">Select City</option>');
                    $.each(res, function (key, value) {
                        $('#city').append('<option value="' + value
                            .dis_id + '">' + value.dis_name + '</option>');
                    });
                }
            });
        });
        $('#edit_country').on('change', function () {
            var countryId = this.value;
            $('#state').html('');
            $.ajax({
                url: '{{ route('getStates') }}?country_id=' + countryId,
                type: 'get',
                async:false,
                success: function (res) {

                    $('#edit_state').html('<option value="">Select State</option>');
                    $.each(res, function (key, value) {
                        $('#edit_state').append('<option value="' + value
                            .sts_id + '">' + value.sts_name + '</option>');
                    });
                    $('#edit_city').html('<option value="">Select City</option>');
                }
            });
        });
        $('#edit_state').on('change', function () {
            var stateId = this.value;
            $('#edit_city').html('');
            $.ajax({
                url: '{{ route('getCities') }}?state_id=' + stateId,
                type: 'get',
                async:false,
                success: function (res) {
                    $('#edit_city').html('<option value="">Select City</option>');
                    $.each(res, function (key, value) {
                        $('#edit_city').append('<option value="' + value
                            .dis_id + '">' + value.dis_name + '</option>');
                    });
                }
            });
        });
    });

</script>
<script>
    $(document).ready(function (e) {
        $(document).on('click', '.data_edit', function (e) {

            var data_id = $(this).attr('data-id');
            console.log(data_id);
            $("#data_id").val(data_id);
            $("#edit_data").trigger('click');
            $.ajax({
                url: '{{ route('getUsersByID') }}',
                type: 'POST',
                async:false,
                data: {id: data_id, _token: '<?= csrf_token() ?>'},
                success: function (res) {
                    $("#edit_fname").val(res.usr_fname);
                    $("#edit_lname").val(res.usr_lname);
                    $("#edit_image_old").val(res.usr_image);
                    $("#edit_image_view"). attr('src','{{asset('upload/Image')}}/'+(res.usr_image==null ? 'no-image.jpg': res.usr_image));
                    // $("#edit_image"). attr('value',res.usr_image);


                    $("#edit_email").val(res.usr_email);
                    $("#edit_phone").val(res.usr_phone);
                    $("#edit_address").val(res.usr_address);
                    $("#edit_pincode").val(res.usr_pincode);
                    $('#edit_gender').val(res.usr_gender).trigger('chosen:updated');
                    $('#edit_country').val(res.cnt_id).trigger('chosen:updated').trigger('change');
                    $('#edit_state').val(res.sts_id).trigger('chosen:updated').trigger('change');
                    $('#edit_city').val(res.dis_id).trigger('chosen:updated');
                    $('#edit_dob').val(res.usr_dob);
                    // console.log(res.fname);
                }
            });

        });
        $("#filter_button").on('click',function () {
           var email = $("#filter_email").val();
           var name = $("#filter_name").val();

        })

    });
    $(document).ready(function (e) {
        $(document).on('click', '.data_delete', function (e) {
            var data_id = $(this).attr('data-id');
            $("#data_id").val(data_id);
            $.ajax({
                url: '{{ route('delete') }}',
                type: 'POST',
                async:false,
                data: {id: data_id, _token: '<?= csrf_token() ?>'},
                success: function (res) {
                    if (res) {
                        $('.users').empty();
                        UsersDataGet();
                    } else {
                        alert("data not successfully insert");
                    }
                }
            });

        });

    });




</script>
<script>
    $(function () {
        $('#save_user_data').validate({
            ignore: '',
            rules: {
                fname: {
                    required: true,
                    maxlength: 50,
                },
                email: {
                    required: true,
                    email: true,
                    maxlength: 100,
                },
                phone: {
                    required: true,
                    digits: true,
                    maxlength: 10,
                },
                gender: {
                    required: true,
                },
                address: {
                    required: true,
                },
                pincode: {
                    required: true,
                    maxlength: 6,
                },
                country: {
                    required: true,
                },
                state: {
                    required: true,
                },
                city: {
                    required: true,
                }

            },
            errorElement: "div",
            errorClass: "help-block-others",
            errorPlacement: function (error, element) {
                element.parent().after(error);
            },
            highlight: function (element) {
                $(element).parent().addClass("has-error");
            },
            unhighlight: function (element) {
                $(element).parent().removeClass("has-error");

            },
            invalidHandler: function (form, validator) {

                if (!validator.numberOfInvalids())
                    return;

                $('html, body').animate({
                    scrollTop: $(validator.errorList[0].element).offset().top - 150
                }, "fast");

            },
            submitHandler: function (form) {
                var formData = new FormData(form);
                $.ajax({
                    url: form.action,
                    type: form.method,
                    data: formData,
                    cache:false,
                    contentType: false,
                    processData: false,
                    success: function (res) {
                        if (res) {
                            $(".close_link").trigger('click');
                            $('.users').empty();
                            UsersDataGet();
                        } else {
                            alert("data not successfully insert");
                        }
                    }
                });
            }
        });
    });
    $(function () {
        $('#edit_user_data').validate({
            ignore: '',
            rules: {
                edit_fname: {
                    required: true,
                    maxlength: 50,
                },
                edit_email: {
                    required: true,
                    email: true,
                    maxlength: 100,
                },
                edit_phone: {
                    required: true,
                    digits: true,
                    maxlength: 10,
                },
                edit_gender: {
                    required: true,
                },
                edit_address: {
                    required: true,
                },
                edit_pincode: {
                    required: true,
                    maxlength: 6,
                },
                edit_country: {
                    required: true,
                },
                edit_state: {
                    required: true,
                },
                edit_city: {
                    required: true,
                }

            },
            errorElement: "div",
            errorClass: "help-block-others",
            errorPlacement: function (error, element) {
                element.parent().after(error);
            },
            highlight: function (element) {
                $(element).parent().addClass("has-error");
            },
            unhighlight: function (element) {
                $(element).parent().removeClass("has-error");

            },
            invalidHandler: function (form, validator) {

                if (!validator.numberOfInvalids())
                    return;

                $('html, body').animate({
                    scrollTop: $(validator.errorList[0].element).offset().top - 150
                }, "fast");

            },
            submitHandler: function (form) {
                var formData = new FormData(form);
                $.ajax({
                    url: form.action,
                    type: form.method,
                    data: formData,
                    cache:false,
                    contentType: false,
                    processData: false,
                    success: function (res) {
                        if (res) {
                            $(".close_link").trigger('click');
                            $('.users').empty();
                            UsersDataGet();
                        } else {
                            alert("data not successfully insert");
                        }
                    }
                });
            }
        });
    });
</script>

<?php //include 'common/footer.php' ?>