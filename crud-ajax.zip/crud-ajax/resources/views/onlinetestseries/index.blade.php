@include('common.header')
<style>
    .card-box {
        margin-top: 20px;
        height: 200px;
        width: 200px;
        margin-bottom: 30px;
    }

    .text-center {
        text-align: center !important;
        padding-top: 75px;
    }

</style>
<div class="container">
    <div class="row">
        <div class="col-4">
            <div class="card card-box">
                <h3 class="text-center">C language</h3>
            </div>
        </div>
        <div class="col-4">
            <div class="card card-box">
                <h3 class="text-center">C++ language</h3>
            </div>
        </div>
        <div class="col-4">
            <div class="card card-box">
                <h3 class="text-center">Java language</h3>
            </div>
        </div>
        <div class="col-4">
            <div class="card card-box">
                <h3 class="text-center">PHP language</h3>
            </div>
        </div>
        <div class="col-4">
            <div class="card card-box">
                <h3 class="text-center">SQL language</h3>
            </div>
        </div>
        <div class="col-4">
            <div class="card card-box">
                <h3 class="text-center">SQL language</h3>
            </div>
        </div>
    </div>
</div>
@include('common.footer')

