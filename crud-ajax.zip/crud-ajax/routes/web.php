<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LocationController;
use App\Http\Controllers\UsersController;
use App\Http\Controllers\OnlineTestSeriesController;
//use App\Http\Controllers\GeoLocationController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Route::get('/', function () {
//    return view('index');
//});
Route::get('/', [LocationController::class, 'view'])->name('view');
Route::get('get-states', [LocationController::class, 'getStates'])->name('getStates');
Route::get('get-cities', [LocationController::class, 'getCities'])->name('getCities');
Route::get('home', [OnlineTestSeriesController::class, 'index'])->name('home');
Route::post('save', [UsersController::class, 'save'])->name('save');
Route::post('edit', [UsersController::class, 'edit'])->name('edit');
Route::post('delete', [UsersController::class, 'delete'])->name('delete');
Route::get('get-users', [UsersController::class, 'getUsers'])->name('getUsers');
Route::post('get-users', [UsersController::class, 'getUsers'])->name('getUsersByID');
Route::get('get-test-users', [UsersController::class, 'getTestUsers'])->name('getTestUsers');
//Route::get('get-users', [UsersController::class, 'getUsers'])->name('getUsers');
//Route::get('get-address-from-ip', [GeoLocationController::class, 'index']);