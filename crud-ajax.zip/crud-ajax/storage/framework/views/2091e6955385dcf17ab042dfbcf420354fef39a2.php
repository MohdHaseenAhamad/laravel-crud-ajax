<?php echo $__env->make('common.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    .card-box {
        margin-top: 20px;
        height: 200px;
        width: 200px;
        margin-bottom: 30px;
    }

    .text-center {
        text-align: center !important;
        padding-top: 75px;
    }

</style>
<div class="container">
    <div class="row">
        <div class="col-4">
            <div class="card card-box">
                <h3 class="text-center">C language</h3>
            </div>
        </div>
        <div class="col-4">
            <div class="card card-box">
                <h3 class="text-center">C++ language</h3>
            </div>
        </div>
        <div class="col-4">
            <div class="card card-box">
                <h3 class="text-center">Java language</h3>
            </div>
        </div>
        <div class="col-4">
            <div class="card card-box">
                <h3 class="text-center">PHP language</h3>
            </div>
        </div>
        <div class="col-4">
            <div class="card card-box">
                <h3 class="text-center">SQL language</h3>
            </div>
        </div>
        <div class="col-4">
            <div class="card card-box">
                <h3 class="text-center">SQL language</h3>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH E:\laravel Projects\crud-ajax\crud-ajax\resources\views/OnlineTestSeries/index.blade.php ENDPATH**/ ?>